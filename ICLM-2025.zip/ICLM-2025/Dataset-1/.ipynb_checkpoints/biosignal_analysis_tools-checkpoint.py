import numpy as np  # Import NumPy for numerical computations
import matplotlib.pyplot as plt  # Import Matplotlib for plotting
from scipy.signal import butter, sosfilt, iirnotch, filtfilt, lfilter  # Import signal processing functions


# Function to plot the signal in the time domain
def plot_signal_time_domain(signal_data):
    """
    Visualize the signal in the time domain.
    """
    plt.clf()  # Clear the current figure
    plt.title("Signal in Time Domain")  # Set the plot title
    plt.plot(signal_data)  # Plot the signal data


# Function to plot the signal in the frequency domain
def plot_signal_frequency_domain(signal_data, sampling_rate):
    """
    Visualize the signal in the frequency domain.
    """
    freq_data = np.fft.rfft(signal_data)  # Perform FFT to get frequency components
    freq_axis = np.fft.rfftfreq(len(signal_data), 1 / sampling_rate)  # Generate frequency axis
    plt.clf()  # Clear the current figure
    plt.title("Signal in Frequency Domain")  # Set the plot title
    plt.plot(freq_axis, np.abs(freq_data))  # Plot frequency vs magnitude
    plt.xlabel("Frequency (Hz)")  # Label the x-axis
    plt.ylabel("Amplitude")  # Label the y-axis


# Function to design a bandpass filter
def design_bandpass_filter(low_cut, high_cut, sampling_rate, order=5):
    """
    Generate a bandpass filter using Butterworth filter design.
    """
    nyquist_freq = 0.5 * sampling_rate  # Calculate the Nyquist frequency
    low = low_cut / nyquist_freq  # Normalize the low cutoff frequency
    high = high_cut / nyquist_freq  # Normalize the high cutoff frequency
    filter_sos = butter(order, [low, high], btype='bandpass', output='sos')  # Design a bandpass filter
    return filter_sos  # Return the filter coefficients


# Function to apply a bandpass filter
def apply_bandpass_filter(signal_data, low_cut=5, high_cut=35, sampling_rate=250, order=5):
    """
    Apply a bandpass filter to the input signal data.
    """
    sos = design_bandpass_filter(low_cut, high_cut, sampling_rate, order)  # Get the filter coefficients
    filtered_output = np.zeros_like(signal_data)  # Initialize filtered output array

    # Apply filter to each channel
    for idx in range(signal_data.shape[1]):
        filtered_output[:, idx] = sosfilt(sos, signal_data[:, idx])  # Apply the filter to each channel

    return filtered_output  # Return the filtered signal


# Function to plot the spectrogram of the signal
def plot_spectrogram(signal_data, sampling_rate, nfft, overlap):
    """
    Generate a spectrogram of the signal.
    """
    plt.title("Spectrogram of Signal")  # Set the plot title
    plt.specgram(signal_data, Fs=sampling_rate, NFFT=nfft, noverlap=overlap)  # Generate spectrogram
    plt.xlabel("Time (s)")  # Label the x-axis
    plt.ylabel("Frequency (Hz)")  # Label the y-axis


# Function to remove DC offset using a high-pass filter
def remove_offset(signal_data, sampling_rate=250, cutoff_freq=0.5, order=3):
    """
    Eliminate DC offset using a high-pass filter.
    """
    nyquist_freq = 0.5 * sampling_rate  # Calculate the Nyquist frequency
    normalized_cutoff = cutoff_freq / nyquist_freq  # Normalize the cutoff frequency
    b, a = butter(order, normalized_cutoff, btype='highpass')  # Design the high-pass filter
    adjusted_data = lfilter(b, a, signal_data)  # Apply the filter to the signal
    return adjusted_data  # Return the filtered signal


# Function to apply a low-pass filter
def apply_lowpass_filter(signal_data, sampling_rate=250, cutoff_freq=0.5, order=3):
    """
    Apply a low-pass filter to the signal.
    """
    nyquist_freq = 0.5 * sampling_rate  # Calculate the Nyquist frequency
    normalized_cutoff = cutoff_freq / nyquist_freq  # Normalize the cutoff frequency
    b, a = butter(order, normalized_cutoff, btype='lowpass')  # Design the low-pass filter
    adjusted_data = lfilter(b, a, signal_data)  # Apply the filter to the signal
    return adjusted_data  # Return the filtered signal


# Function to remove powerline noise using a notch filter
def remove_powerline_noise(signal_data, sampling_rate=250, line_freq=60.0, q_factor=30.0):
    """
    Remove powerline interference using a notch filter.
    """
    signal_data = signal_data.transpose()  # Transpose the data for channel-wise filtering
    b, a = iirnotch(line_freq, q_factor, sampling_rate)  # Design the notch filter
    noise_free_data = filtfilt(b, a, signal_data, padlen=len(signal_data) - 1)  # Apply the filter
    return noise_free_data.transpose()  # Transpose the data back to original shape


# Class for computing signal features
class SignalFeatures:
    """
    Compute various features from the biosignal in the time domain.
    """

    def __init__(self, signal_data):
        self.signal_data = signal_data  # Store the input signal data

    def mean_absolute_value(self, axis=2):
        """
        Compute the mean absolute value (MAV) of the signal.
        """
        return np.sum(np.abs(self.signal_data), axis=axis) / self.signal_data.shape[axis]  # Calculate MAV

    def standard_deviation(self, axis=2):
        """
        Compute the standard deviation of the signal.
        """
        mean_values = np.mean(self.signal_data, axis=axis)  # Compute the mean of the signal
        centered = self.signal_data - np.expand_dims(mean_values, axis=axis)  # Center the data around the mean
        variance = np.sum(np.square(centered), axis=axis) / (self.signal_data.shape[axis] - 1)  # Compute variance
        return np.sqrt(variance)  # Compute the standard deviation

    def variance(self, axis=2):
        """
        Compute the variance of the signal.
        """
        return np.sum(np.square(self.signal_data), axis=axis) / (self.signal_data.shape[axis] - 1)  # Calculate variance

    def waveform_length(self, axis=2):
        """
        Compute the waveform length (WL) of the signal.
        """
        differences = np.diff(self.signal_data, axis=axis, prepend=self.signal_data[..., :1])  # Compute differences
        return np.sum(np.abs(differences), axis=axis)  # Compute the waveform length

    def root_mean_square(self, axis=2):
        """
        Compute the root mean square (RMS) of the signal.
        """
        mean_square = np.sum(np.square(self.signal_data), axis=axis) / self.signal_data.shape[axis]  # Compute mean square
        return np.sqrt(mean_square)  # Compute the RMS

